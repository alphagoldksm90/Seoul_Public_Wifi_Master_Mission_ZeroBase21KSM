package com.example.seoulpublicwifi.common;

public class Db {
    public static final String URL = "jdbc:sqlite://Users/suhwan/Desktop/seoul-public-wifi/wifi.db";
    public static final String CLASS = "org.sqlite.JDBC";
}
